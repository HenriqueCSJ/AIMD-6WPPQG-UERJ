# Referência opcional · Al³⁺, água e amônia

[← Percurso](../README.md) · [Abrir as duas trajetórias](../../visualizador/index.html?exemplo=aluminum&aba=trajetoria)

**15 min · XTB2 · 23 átomos · 2 ps = 2 × 10⁻¹² s**

> **Pergunta:** a amônia se liga ao alumínio ou recebe um próton de uma água coordenada?

No dímero neutro, uma troca de contato não significava transferência de H. No complexo de Zn, distinguimos vizinhança de coordenação. Use agora essas duas perguntas para investigar Al³⁺, seis águas e uma NH₃ afastada com **XTB2**. Não acrescentamos solvente implícito, parede nem otimização inicial. É um agregado isolado, com carga total +3 e multiplicidade 1.

## 1. Execute

[Pacote de 1 fs](aula-al_agua_nh3_scc.zip) · [Pacote de 0,5 fs](aula-al_agua_nh3_dt05.zip) · [Estrutura inicial](estruturas/al_agua_nh3.xyz)

Para reproduzir esta referência opcional, prefira **0,5 fs**; o pacote de **1 fs** conserva o passo do exemplo proposto para comparação. Ambos chegam a 2 ps. Execute apenas um e abra a outra referência pronta.

**Atenção ao terceiro arquivo:** cada pacote contém o input, a geometria e `scc.inp`. Mantenha os três na mesma pasta. A troca direta para XTB2, sem esse ajuste de convergência, falhou antes da dinâmica nesta geometria. [Entenda o ajuste e consulte o diagnóstico](apoio.md).

<details markdown="1" open><summary>Input de 0,5 fs · recomendado para reprodução</summary>

[Baixar input ORCA](inputs/al_agua_nh3_dt05.inp) · [Baixar geometria inicial (.xyz)](estruturas/al_agua_nh3.xyz) (obrigatório; manter na mesma pasta do input) · [Baixar scc.inp obrigatório](inputs/scc.inp) (manter junto do input e do XYZ)

**Input completo · `scc.inp` — copie e salve com esse nome.**

<!-- input-source: inputs/scc.inp -->
```text
$scc
  broydamp=0.1
  iterations=1000
$write
  output file=properties.out
$end
```


<!-- input-source: inputs/al_agua_nh3_dt05.inp -->
```text
# Caso fornecido: Al3+ + 6 aguas + NH3, agora com XTB2.
! MD XTB2 PAL8
%maxcore 256
# Reduz a mistura SCC para esta geometria ionica; requer scc.inp.
%xtb
  XTBINPUTSTRING "--input scc.inp"
end
%md
  # Semente fixa para reproduzir as velocidades iniciais.
  Randomize 42
  Initvel 300_K
  # Controle: mesmo ponto inicial e banho; passo reduzido para conferir a reacao.
  Timestep 0.5_fs
  Thermostat Berendsen 300_K Timecon 20.0_fs
  Dump Position Stride 1 Filename "al_agua_nh3_dt05-traj.xyz"
  # 4000 x 0.5 fs = 2 ps = 2e-12 s.
  Run 4000
end
# Carga total +3 e multiplicidade 1; geometria original sem pre-otimizacao.
* xyzfile 3 1 al_agua_nh3.xyz
```

</details>

<details markdown="1" open><summary>Input de 1 fs · passo do exemplo original</summary>

[Baixar input ORCA](inputs/al_agua_nh3_scc.inp) · [Baixar geometria inicial (.xyz)](estruturas/al_agua_nh3.xyz) (obrigatório; manter na mesma pasta do input) · [Baixar scc.inp obrigatório](inputs/scc.inp) (manter junto do input e do XYZ)

<!-- input-source: inputs/al_agua_nh3_scc.inp -->
```text
# Caso fornecido: Al3+ + 6 aguas + NH3, agora com XTB2.
! MD XTB2 PAL8
%maxcore 256
# Reduz a mistura SCC para esta geometria ionica; requer scc.inp.
%xtb
  XTBINPUTSTRING "--input scc.inp"
end
%md
  # Semente fixa para reproduzir as velocidades iniciais.
  Randomize 42
  Initvel 300_K
  # Preserva o passo e o banho do exemplo; conferir a sensibilidade ao passo.
  Timestep 1.0_fs
  Thermostat Berendsen 300_K Timecon 20.0_fs
  Dump Position Stride 1 Filename "al_agua_nh3_scc-traj.xyz"
  # 2000 x 1 fs = 2 ps = 2e-12 s.
  Run 2000
end
# Carga total +3 e multiplicidade 1; geometria original sem pre-otimizacao.
* xyzfile 3 1 al_agua_nh3.xyz
```

</details>

<details markdown="1"><summary>Arquivo adicional scc.inp · ajuste numérico</summary>

O parâmetro `broydamp` reduz a mistura das cargas entre iterações; `iterations` aumenta o teto de iterações. Não é aquecimento e não é uma força aplicada aos átomos. O Hamiltoniano continua GFN2-xTB, com temperatura eletrônica de 300 K.

```text
$scc
  broydamp=0.1
  iterations=1000
$write
  output file=properties.out
$end
```

</details>

<details markdown="1"><summary>Coordenadas originais · al_agua_nh3.xyz</summary>

```text
23
Geometria fornecida por Henrique; Al(H2O)6 + NH3; carga total +3; singleto
Al        -1.69843        0.30039       -0.52660
O         -1.75434        2.28860       -0.16768
H         -1.06074        2.96658       -0.39426
H         -2.57402        2.86004       -0.19067
O          0.18914        0.01137       -1.09162
H          0.74757        0.53633       -1.72122
H          0.81910       -0.68284       -0.76495
O         -4.16028        0.33340        0.21207
H         -4.88863       -0.23860       -0.13918
H         -4.41422        0.36961        1.17124
O         -1.89953       -1.63320       -0.98875
H         -1.18917       -2.30830       -0.84601
H         -2.72113       -2.18200       -0.88390
O         -2.27717        0.41996       -2.39043
H         -1.95369       -0.26864       -3.02303
H         -2.55489        1.18412       -2.95722
O         -1.29833        0.19812        1.32935
H         -0.88999        0.97238        1.79308
H         -1.06866       -0.60048        1.86891
N         -7.75307        0.21769        1.57284
H         -7.36248       -0.21900        2.40779
H         -8.23546        1.07792        1.83306
H         -8.41348       -0.42234        1.13168
```

</details>

<details markdown="1"><summary>Executar no Ubuntu / WSL2</summary>

Entre na **pasta extraída do exercício**, onde estão o input e seus arquivos auxiliares. Com a [instalação concluída](../../tutoriais/01-wsl2-ubuntu-orca.md), execute:

```bash
orca al_agua_nh3_dt05.inp > al_agua_nh3_dt05.out &
```

Espere o cálculo encerrar antes de iniciar outro. Os resultados ficam nessa mesma pasta; veja [como acompanhar a execução](../README.md#como-executar).

Para o teste de 1 fs, use o outro pacote e substitua `al_agua_nh3_dt05` por `al_agua_nh3_scc`.

</details>

O teste de **0,5 fs levou 96,4 s**; o de **1 fs, 49,3 s**, no Intel Core Ultra 9 185H, WSL2, ORCA 6.1.1 / xTB 6.7.1, PAL8. São medições desta máquina. A execução é opcional; os resultados prontos permitem fazer a interpretação sem esperar.

## 2. Procure o evento, não apenas o movimento

[Abrir no laboratório](../../visualizador/index.html?exemplo=aluminum&aba=trajetoria). O seletor da trajetória alterna os dois passos; ambos preservam todos os quadros.

1. Pause perto de **0,14–0,20 ps** (1,4–2,0 × 10⁻¹³ s). Ative os índices dos átomos.
2. Meça **O 7–H 9** e **N 19–H 9**. Esses índices começam em zero, como no visualizador. Na contagem convencional, são O8, H10 e N20.
3. Acompanhe **Al 0–N 19**: a amônia chega a formar uma ligação direta com o metal? Compare com as distâncias Al–O.
4. Vá ao final. Conte os H ligados ao N e ao O 7. Depois compare o pico de temperatura com o alvo de 300 K do termostato.

**O que as referências mostram:** o H 9 passa da água para a amônia, retorna brevemente e depois permanece no N até o final. Em 0,5 fs, a primeira troca de vizinho mais próximo ocorre aos **147 fs** e a última aos **178,5 fs**; em 1 fs, aos **148 e 178 fs**. O N termina com quatro H e o O 7 com um. Não são cinco transferências independentes: há recrossamentos do mesmo H.

A mudança geométrica é compatível com:

**[Al(H₂O)₆]³⁺ + NH₃ → [Al(H₂O)₅(OH)]²⁺ + NH₄⁺**

O Al³⁺ atua como ácido de Lewis e favorece a acidez da água coordenada; a amônia recebe o H como base. A reação escrita usa a atribuição química de cargas formais. A análise da trajetória identifica vizinhos e ligações por geometria, sem medir cargas inteiras dos fragmentos.

**Não houve coordenação Al–N:** a menor distância ficou em cerca de **4,09 Å** no controle de 0,5 fs. O fragmento com quatro N–H se afasta e Al–N termina em **56,19 Å**. Sem parede ou meio contínuo, o modelo permite separação livre dos produtos. No mesmo controle, Al–O 7 contrai de **2,57 para 1,65 Å**, compatível com a formação do ligante hidroxo.

## 3. O que este exemplo permite discutir?

- **Transferência versus reorientação.** No dímero, a rede de contatos H muda; aqui um H muda persistentemente de O para N.
- **Temperatura do banho versus temperatura instantânea.** O alvo é 300 K, mas o controle de 0,5 fs atinge aproximadamente **705 K** durante a reorganização inicial. O termostato remove energia ao longo do tempo; ele não fixa cada quadro em 300 K.
- **Sensibilidade ao timestep.** Reduzir o passo preservou o evento qualitativo nesta condição inicial. Isso é um controle numérico útil, não uma validação geral do método ou da cinética.

Berendsen com acoplamento de 20 fs foi mantido do exemplo proposto. É forte acoplamento e não gera a distribuição canônica exata. A geometria inicial não foi equilibrada; o gap eletrônico inicial pequeno produz ocupações fracionárias no xTB. Por isso, esta é uma **demonstração exploratória de reação**, não uma medida de pKa, barreira, velocidade ou comportamento do Al³⁺ em solução. A diferença de energia potencial entre os extremos inclui relaxação, transferência e separação; não é uma entalpia de reação.

## Resultados e leitura

As referências abaixo são XTB2. A tentativa DFT foi interrompida; não há uma trajetória DFT completa para esta comparação.

- **0,5 fs:** [output](resultados/al_agua_nh3_dt05/al_agua_nh3_dt05.out) · [energias](resultados/al_agua_nh3_dt05/al_agua_nh3_dt05-md-ener.csv) · [trajetória](resultados/al_agua_nh3_dt05/al_agua_nh3_dt05-traj.xyz) · [medidas e eventos](resultados/al_agua_nh3_dt05/analysis.json).
- **1 fs:** [output](resultados/al_agua_nh3_scc/al_agua_nh3_scc.out) · [energias](resultados/al_agua_nh3_scc/al_agua_nh3_scc-md-ener.csv) · [trajetória](resultados/al_agua_nh3_scc/al_agua_nh3_scc-traj.xyz) · [medidas e eventos](resultados/al_agua_nh3_scc/analysis.json).
- [ORCA: MD, passos de integração e termostatos](https://www.faccts.de/docs/orca/6.1/manual/contents/moleculardynamics/moldyn.html).
- [ORCA: XTB2 e XTBINPUTSTRING](https://www.faccts.de/docs/orca/6.1/manual/contents/modelchemistries/semiempirical.html).
- [xTB: opções do controle SCC](https://github.com/grimme-lab/xtb/blob/main/man/xcontrol.7.adoc).

**Para registrar:** cite duas distâncias que distinguem transferência de próton de coordenação da amônia ao Al. Explique por que o alvo de 300 K não impede um pico de temperatura.
